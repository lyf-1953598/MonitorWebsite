module.exports = {
    publicPath: process.env.NODE_ENV === "production" ? "./" : "./",
    publicPath:'./',
    // baseUrl: './', 
    configureWebpack: {
      externals: {
        'echarts': 'echarts',
        'moment': 'moment'
      }
    }
  }