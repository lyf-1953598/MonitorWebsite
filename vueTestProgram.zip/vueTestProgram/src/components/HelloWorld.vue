<style scoped>
@import url("https://at.alicdn.com/t/font_2431045_hbwl3x53oep.css");
@import "../assets/css/index.css";
@import "../assets/css/picker.css";
@import "../assets/css/main.css";
</style>
<template>
  <div class="all-container">
    <div class="toolcontainer">
      <input type="file" id="fileInput" onchange="handleFile(event)" />
      <button onclick="exportData()">导出表格</button>
    </div>

    <div class="chartcontainer">
      <div class="wrap-container">
        <div class="wrap hide">
          <div class="wrap-l">
            <i class="ali-iconfont ali-iconshizhong"></i>
            <div class="wrap-l-starTime">
              <input name="startTime" type="text" placeholder="开始日期" />
            </div>
          </div>
          <div class="wrap-r">
            <i class="ali-iconfont ali-iconshizhong"></i>
            <div class="wrap-l-endTime">
              <input name="endTime" type="text" placeholder="结束日期" />
            </div>
          </div>
        </div>
      </div>
      <div id="main" style="width: 1200px; height: 600px"></div>
    </div>
    <div class="chartcontainer">
      <div id="lineMain" style="width: 1200px; height: 600px"></div>
    </div>
    <div class="chartcontainer">
      <div id="lineDDM" style="width: 1200px; height: 600px"></div>
    </div>
    <!-- 表格呈现 -->
    <div class="gridcontainer">
      <div
        id="myGrid"
        class="ag-theme-alpine"
        style="height: 800px; width: 100%"
      ></div>
    </div>
    <div class="gridcontainer">
      <div
        id="myGridAnother"
        class="ag-theme-alpine"
        style="height: 800px; width: 100%"
      ></div>
    </div>
  </div>
</template>

<script>
</script>



